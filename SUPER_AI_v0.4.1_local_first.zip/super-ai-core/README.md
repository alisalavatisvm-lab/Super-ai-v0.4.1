# SUPER AI — Core v0.4.1

A runnable foundation for a provider-neutral multi-agent assistant. The backend exposes health, agent registry, and orchestration endpoints. When explicitly enabled and configured with an OpenAI-compatible model endpoint, the orchestrator runs planner and analyst in parallel, sends their work to a critic, synthesizes a final answer, and applies a bounded quality-review loop.

## Important capability boundary
Without model credentials, `/api/v1/chat` intentionally returns a clearly labeled DEMO response. It does not pretend to be an AI model. The quality score is a lightweight heuristic, not a factuality guarantee or independent truth verification. External evidence retrieval, encrypted-at-rest memory, multi-user identity management, and production deployment are not implemented yet.

## Run locally (Windows 11)
1. Install Python 3.11+.
2. In PowerShell, from this folder:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   Copy-Item .env.example .env
   uvicorn backend.main:app --reload
   ```
3. Open `http://127.0.0.1:8000/docs`.
4. Cloud inference is disabled by default. Do not set `CLOUD_INFERENCE_ENABLED=true` while the approved monthly budget is USD 0.00. Enable it only after implementing and verifying the per-operation approval and spend-ledger controls. Never commit `.env`.

## API
- `GET /api/v1/health`
- `GET /api/v1/agents`
- `POST /api/v1/chat` with JSON `{ "message": "..." }`

## Tests
```powershell
pytest -q
```

## Architecture direction
The next engineering increments are: persistent conversation/session memory (PostgreSQL + pgvector), Redis-backed job and rate controls, authenticated Android client, observability, provider capability negotiation, and evaluation using a versioned test set with regression gates.

## Zero-cloud safety patch (v0.3.1)
`CLOUD_INFERENCE_ENABLED` defaults to `false`. Provider credentials do not enable cloud calls by themselves. With the current owner-approved USD 0.00 monthly budget, leave this flag disabled. This safety switch is not a substitute for the future approval and spend-ledger subsystem.

## Local conversation memory (v0.4.0)
The core now stores sessions and message turns in SQLite. The default database is `data/super_ai.db`; override it with `DATABASE_PATH` (default `data/super_ai.db`).

Additional endpoints:
- `POST /api/v1/sessions` with `{ "title": "My session" }`
- `GET /api/v1/sessions`
- `GET /api/v1/sessions/{session_id}/messages`

`POST /api/v1/chat` accepts an optional `session_id`. If omitted, a session is created automatically. The response includes the `session_id` for continuing the conversation.

SQLite data is not encrypted. Keep the development service on a trusted network. Cloud inference remains disabled by default; the DEMO response is not a substitute for a connected local language model. If `LOCAL_MODEL_BASE_URL` and `LOCAL_MODEL_NAME` are configured, the local OpenAI-compatible endpoint (for example Ollama) is selected before the cloud provider. The last 12 messages in a session are supplied as context to model-backed runs.


## Local model and API access protection (v0.4.1)
- Configure `LOCAL_MODEL_BASE_URL=http://127.0.0.1:11434/v1` and `LOCAL_MODEL_NAME=<installed-model>` for an Ollama-compatible local endpoint. No cloud credentials or paid API are needed. The model itself must already be installed and running on the host.
- Set a long random `API_ACCESS_TOKEN` to require `Authorization: Bearer <token>` on data endpoints. `/health` remains public for health checks. Leave the service on a trusted network; this is a single shared token, not per-user identity management.
- Android includes an optional token field for connecting to a protected Core.
- Session history is included as context (up to the last 12 messages) when a model is configured. DEMO mode remains explicitly non-AI.
