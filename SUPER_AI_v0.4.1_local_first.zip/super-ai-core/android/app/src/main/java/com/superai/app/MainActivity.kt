package com.superai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SuperAiScreen() }
    }
}

@Composable
private fun SuperAiScreen() {
    var endpoint by remember { mutableStateOf("http://10.0.2.2:8000") }
    var prompt by remember { mutableStateOf("") }
    var accessToken by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("SUPER AI آماده است. آدرس Core را تنظیم کن و درخواستت را بنویس.") }
    var busy by remember { mutableStateOf(false) }
    var sessionId by remember { mutableStateOf<String?>(null) }
    var savedSessions by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    val scope = rememberCoroutineScope()
    val client = remember { OkHttpClient() }
    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("SUPER AI", style = MaterialTheme.typography.headlineLarge)
                Text("Multi-Agent Intelligence • Core v0.4.1", style = MaterialTheme.typography.bodyMedium)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(if (sessionId == null) "گفتگوی تازه" else "حافظه فعال: ${sessionId!!.take(8)}…", style = MaterialTheme.typography.labelSmall)
                    TextButton(onClick = { sessionId = null; answer = "گفتگوی تازه آماده است." }, enabled = !busy) { Text("گفتگوی جدید") }
                }
                TextButton(onClick = {
                    if (busy) return@TextButton
                    busy = true
                    scope.launch {
                        try {
                            val loaded = withContext(Dispatchers.IO) {
                                val builder = Request.Builder().url(endpoint.trimEnd('/') + "/api/v1/sessions?limit=30").get()
                                if (accessToken.isNotBlank()) builder.header("Authorization", "Bearer $accessToken")
                                client.newCall(builder.build()).execute().use { response ->
                                    val raw = response.body?.string().orEmpty()
                                    if (!response.isSuccessful) error("HTTP ${response.code}: $raw")
                                    val array = org.json.JSONArray(raw)
                                    (0 until array.length()).map { i ->
                                        val item = array.getJSONObject(i)
                                        item.getString("session_id") to item.optString("title", "گفتگو")
                                    }
                                }
                            }
                            savedSessions = loaded
                        } catch (e: Exception) { answer = "خطا در دریافت گفتگوها: ${e.message}" }
                        busy = false
                    }
                }, enabled = !busy) { Text("بارگذاری گفتگوهای ذخیره‌شده") }
                savedSessions.take(8).forEach { item ->
                    TextButton(onClick = {
                        if (busy) return@TextButton
                        busy = true
                        scope.launch {
                            try {
                                val transcript = withContext(Dispatchers.IO) {
                                    val builder = Request.Builder().url(endpoint.trimEnd('/') + "/api/v1/sessions/${item.first}/messages").get()
                                    if (accessToken.isNotBlank()) builder.header("Authorization", "Bearer $accessToken")
                                    client.newCall(builder.build()).execute().use { response ->
                                        val raw = response.body?.string().orEmpty()
                                        if (!response.isSuccessful) error("HTTP ${response.code}: $raw")
                                        val array = org.json.JSONArray(raw)
                                        (0 until array.length()).joinToString("\n\n") { i ->
                                            val msg = array.getJSONObject(i)
                                            (if (msg.optString("role") == "user") "شما" else "SUPER AI") + ":\n" + msg.optString("content")
                                        }
                                    }
                                }
                                sessionId = item.first
                                answer = transcript.ifBlank { "این گفتگو هنوز پیامی ندارد." }
                            } catch (e: Exception) { answer = "خطا در بازیابی گفتگو: ${e.message}" }
                            busy = false
                        }
                    }, enabled = !busy) { Text(item.second.take(48)) }
                }
                OutlinedTextField(endpoint, { endpoint = it }, label = { Text("Core URL") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(accessToken, { accessToken = it }, label = { Text("Access token (if enabled on Core)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(prompt, { prompt = it }, label = { Text("درخواست شما") }, modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp))
                Button(onClick = {
                    if (prompt.isBlank() || busy) return@Button
                    busy = true
                    answer = "در حال پردازش..."
                    scope.launch {
                        answer = try {
                            withContext(Dispatchers.IO) {
                                val payload = JSONObject().put("message", prompt)
                                sessionId?.let { payload.put("session_id", it) }
                                val body = payload.toString().toRequestBody("application/json".toMediaType())
                                val builder = Request.Builder().url(endpoint.trimEnd('/') + "/api/v1/chat").post(body)
                                if (accessToken.isNotBlank()) builder.header("Authorization", "Bearer $accessToken")
                                val request = builder.build()
                                client.newCall(request).execute().use { response ->
                                    val raw = response.body?.string().orEmpty()
                                    if (!response.isSuccessful) error("HTTP ${response.code}: $raw")
                                    val json = JSONObject(raw)
                                    sessionId = json.optString("session_id").takeIf { it.isNotBlank() && it != "null" }
                                    json.optString("answer", "پاسخ خالی از سرور")
                                }
                            }
                        } catch (e: Exception) { "خطا در اتصال: ${e.message}" }
                        busy = false
                    }
                }, enabled = !busy && prompt.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                    Text(if (busy) "در حال تحلیل..." else "ارسال به SUPER AI")
                }
                Text("پاسخ", style = MaterialTheme.typography.titleLarge)
                Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
                    Text(answer, Modifier.padding(16.dp), style = MaterialTheme.typography.bodyLarge)
                }
                Text("نکته: برای شبیه‌ساز اندروید از 10.0.2.2 استفاده کن؛ برای گوشی واقعی، IP رایانه یا سرور را وارد کن. اگر توکن دسترسی روی Core تنظیم شده، همان را بالا وارد کن.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
