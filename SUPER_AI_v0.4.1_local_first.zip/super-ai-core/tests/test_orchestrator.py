import asyncio
import pytest
from backend.core.orchestrator import run_parallel

class StubAgent:
    def __init__(self, agent_id, output):
        self.agent_id, self.output = agent_id, output
    async def run(self, task):
        await asyncio.sleep(0)
        return f"{self.output}:{task}"

@pytest.mark.asyncio
async def test_parallel_agents_return_results():
    agents = [StubAgent("a", "A"), StubAgent("b", "B")]
    results = await run_parallel("check", agents)
    assert [r.agent_id for r in results] == ["a", "b"]
    assert [r.output for r in results] == ["A:check", "B:check"]

@pytest.mark.asyncio
async def test_empty_task_rejected():
    with pytest.raises(ValueError):
        await run_parallel(" ", [StubAgent("a", "A")])
