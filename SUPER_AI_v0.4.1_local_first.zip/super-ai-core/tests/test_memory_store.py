from backend.core.memory_store import MemoryStore


def test_session_and_messages_persist(tmp_path):
    db = tmp_path / "memory.sqlite3"
    store = MemoryStore(str(db))
    session = store.create_session("Test conversation")
    sid = session["session_id"]
    store.add_message(sid, "user", "Hello")
    store.add_message(sid, "assistant", "Hi", {"mode": "demo"})

    # Re-open the database to prove persistence across store instances.
    reopened = MemoryStore(str(db))
    messages = reopened.get_messages(sid)
    assert [m["role"] for m in messages] == ["user", "assistant"]
    assert messages[1]["metadata"] == {"mode": "demo"}
    assert reopened.list_sessions()[0]["message_count"] == 2


def test_missing_session_returns_none(tmp_path):
    store = MemoryStore(str(tmp_path / "memory.sqlite3"))
    assert store.get_messages("missing-session") is None
