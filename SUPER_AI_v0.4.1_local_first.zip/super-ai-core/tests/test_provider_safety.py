from backend.providers.openai_compatible import OpenAICompatibleProvider
from backend.core.config import settings

def test_cloud_provider_is_disabled_by_default(monkeypatch):
    monkeypatch.setattr(settings, "cloud_inference_enabled", False)
    monkeypatch.setattr(settings, "model_base_url", "https://example.invalid/v1")
    monkeypatch.setattr(settings, "model_api_key", "test-key")
    monkeypatch.setattr(settings, "model_name", "test-model")
    provider = OpenAICompatibleProvider()
    assert provider.configured is False

def test_cloud_provider_requires_all_credentials_and_explicit_enable(monkeypatch):
    monkeypatch.setattr(settings, "cloud_inference_enabled", True)
    monkeypatch.setattr(settings, "model_base_url", "https://example.invalid/v1")
    monkeypatch.setattr(settings, "model_api_key", "test-key")
    monkeypatch.setattr(settings, "model_name", "test-model")
    assert OpenAICompatibleProvider().configured is True
    monkeypatch.setattr(settings, "model_api_key", "")
    assert OpenAICompatibleProvider().configured is False

def test_local_provider_configured_without_cloud_credentials(monkeypatch):
    from backend.providers.local_ollama import LocalOllamaProvider
    monkeypatch.setattr(settings, "local_model_base_url", "http://127.0.0.1:11434/v1")
    monkeypatch.setattr(settings, "local_model_name", "qwen2.5:3b")
    monkeypatch.setattr(settings, "cloud_inference_enabled", False)
    monkeypatch.setattr(settings, "model_api_key", "")
    assert LocalOllamaProvider().configured is True


def test_local_provider_not_configured_without_model_name(monkeypatch):
    from backend.providers.local_ollama import LocalOllamaProvider
    monkeypatch.setattr(settings, "local_model_base_url", "http://127.0.0.1:11434/v1")
    monkeypatch.setattr(settings, "local_model_name", "")
    assert LocalOllamaProvider().configured is False

def test_orchestrator_prefers_local_provider_without_cloud(monkeypatch):
    from backend.core.orchestrator import Orchestrator
    monkeypatch.setattr(settings, "local_model_base_url", "http://127.0.0.1:11434/v1")
    monkeypatch.setattr(settings, "local_model_name", "qwen2.5:3b")
    monkeypatch.setattr(settings, "cloud_inference_enabled", False)
    assert Orchestrator().provider.provider_name == "local-openai-compatible"
