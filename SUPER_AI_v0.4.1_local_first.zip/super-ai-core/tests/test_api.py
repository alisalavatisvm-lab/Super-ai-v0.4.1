from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)

def test_health():
    response = client.get("/api/v1/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}

def test_agents_registry():
    response = client.get("/api/v1/agents")
    assert response.status_code == 200
    ids = {item["agent_id"] for item in response.json()}
    assert {"planner", "analyst", "critic", "synthesizer"} <= ids

def test_chat_demo_mode_is_honest():
    response = client.post("/api/v1/chat", json={"message": "Explain Ohm's law"})
    assert response.status_code == 200
    assert response.json()["mode"] == "demo"
    assert "no language model is connected" in response.json()["answer"]

def test_chat_rejects_empty_message():
    response = client.post("/api/v1/chat", json={"message": ""})
    assert response.status_code == 422

def test_chat_creates_and_continues_persistent_session(tmp_path, monkeypatch):
    from backend.core.config import settings
    monkeypatch.setattr(settings, "database_path", str(tmp_path / "api.sqlite3"))

    first = client.post("/api/v1/chat", json={"message": "First turn"})
    assert first.status_code == 200
    session_id = first.json()["session_id"]

    second = client.post("/api/v1/chat", json={"message": "Second turn", "session_id": session_id})
    assert second.status_code == 200
    history = client.get(f"/api/v1/sessions/{session_id}/messages")
    assert history.status_code == 200
    assert [m["role"] for m in history.json()] == ["user", "assistant", "user", "assistant"]


def test_chat_rejects_unknown_session():
    response = client.post("/api/v1/chat", json={"message": "Hello", "session_id": "unknown"})
    assert response.status_code == 404

def test_api_token_protects_data_endpoints_but_not_health(monkeypatch):
    from backend.core.config import settings
    monkeypatch.setattr(settings, "api_access_token", "test-secret-token")
    assert client.get("/api/v1/health").status_code == 200
    assert client.get("/api/v1/agents").status_code == 401
    assert client.get("/api/v1/agents", headers={"Authorization": "Bearer test-secret-token"}).status_code == 200

def test_api_supplies_prior_session_turns_to_orchestrator(tmp_path, monkeypatch):
    from backend.core.config import settings
    import backend.api.routes as routes
    monkeypatch.setattr(settings, "database_path", str(tmp_path / "context.sqlite3"))
    seen = {}
    class FakeOrchestrator:
        async def run(self, task, conversation_context=""):
            seen["task"] = task
            seen["context"] = conversation_context
            return {"answer": "test answer", "mode": "test", "provider": "fake"}
    monkeypatch.setattr(routes, "Orchestrator", FakeOrchestrator)
    first = client.post("/api/v1/chat", json={"message": "Remember this phrase: blue comet"})
    assert first.status_code == 200
    sid = first.json()["session_id"]
    second = client.post("/api/v1/chat", json={"message": "What phrase did I say?", "session_id": sid})
    assert second.status_code == 200
    assert "blue comet" in seen["context"]
    assert seen["task"] == "What phrase did I say?"
