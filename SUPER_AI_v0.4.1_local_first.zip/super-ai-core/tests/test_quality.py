import pytest
from backend.evaluation.quality import evaluate_answer

def test_quality_score_is_bounded():
    report = evaluate_answer("Explain a circuit", "This answer explains a circuit and its assumptions in detail. " * 5, 0.5)
    assert 0.0 <= report.score <= 1.0

def test_invalid_threshold_does_not_crash():
    report = evaluate_answer("question", "answer", 0.8)
    assert isinstance(report.passed, bool)
