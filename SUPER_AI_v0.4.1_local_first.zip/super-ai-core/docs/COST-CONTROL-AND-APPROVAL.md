# SUPER AI — Cost control and approval policy

**Owner decision:** controlled cost, with a spending ceiling and explicit approval.

## Fail-closed defaults

- Monthly cloud spend ceiling: **USD 0.00 until explicitly configured by the owner**.
- Paid cloud provider enabled: **no** by default.
- Cloud approval required: **yes**, for every operation that may incur a charge.
- Local inference: may run without cloud API charges, but must still disclose local compute/resource requirements.
- If pricing or token usage cannot be estimated reliably, do not submit the paid request; ask for approval based on a conservative estimate or use an eligible local route.

## Required approval sequence

1. The backend resolves the task plan and the providers/models that would be called.
2. It estimates prompt and completion tokens per call, including all agents, retries, tool calls, and synthesis.
3. It calculates a conservative maximum cost using a versioned price table and includes currency, model, provider, and assumptions.
4. The Android app displays the estimate and the amount of the configured monthly ceiling already consumed.
5. The owner approves that specific operation and a maximum amount. Approval is scoped to the request, model/provider set, and expiry; it is not blanket consent for future calls.
6. The backend reserves the estimated amount transactionally before dispatch. Concurrent requests cannot reserve beyond the ceiling.
7. After completion, actual provider-reported usage is reconciled to the ledger. Missing usage data is treated conservatively, not as zero.
8. If the estimate exceeds the approval, the monthly ceiling, or remaining budget, the call is blocked. Retries and quality-review loops must consume the same reservation and stay within the approved maximum.

## Ledger requirements

Persist at least: operation ID, user ID, provider, model, price-table version, estimated input/output tokens, reserved amount, actual reported usage, actual cost, currency, approval record, timestamps, outcome, and reconciliation status.

Use database transactions/row locks or an equivalent atomic reservation mechanism. A process-local counter is not sufficient for a multi-worker deployment. Store monetary amounts as integer minor units or fixed-precision decimals; never binary floating point.

## Security requirements

- Provider API keys exist only on the backend secret store/environment, never in Android resources, source control, logs, or client requests.
- Authenticate the Android client and authorize every approval against the authenticated owner.
- Approval records must be server-verifiable, single-use, short-lived, and bound to the exact operation.
- Audit approvals, denials, provider errors, usage reconciliation, and ceiling changes.
- Do not let the client self-assert that an approval is valid.

## Required UI before enabling paid inference

Show provider/model, estimated maximum cost, currency, monthly ceiling, month-to-date spend, remaining amount, and an explicit Approve once / Cancel choice. A settings screen must allow the owner to set or lower the ceiling. Raising the ceiling requires an explicit confirmation.

## Unresolved owner input

The exact monthly ceiling and currency have not yet been specified. Until the owner chooses them, the system must keep paid cloud inference disabled. No amount is assumed.
