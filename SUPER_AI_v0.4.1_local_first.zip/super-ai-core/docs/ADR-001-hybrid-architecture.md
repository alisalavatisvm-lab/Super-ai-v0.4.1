# SUPER AI — Architecture Decision Record 001

**Status:** Accepted  
**Decision date:** 2026-11-11  
**Product target:** Installable Android application for Samsung Galaxy A57; Windows 11 remains the full development target.

## Accepted decisions

1. **Hybrid inference:** support cloud-hosted models and locally hosted models behind one provider-neutral interface. Local inference is an extension point, not a promise that the phone can run every large model efficiently.
2. **Controlled spending:** no paid cloud inference without an explicit per-operation approval and a configured hard spending ceiling. The default cloud spending ceiling is zero until the owner sets one.
3. **Provider independence:** provider adapters are replaceable; orchestration logic must not depend on one vendor's SDK or response format.
4. **Android is a client:** provider credentials and billing logic stay on the backend. Never embed provider API keys in the APK.
5. **Quality gates:** planning, independent analysis, critique, synthesis, and evaluation are separate stages. A heuristic score is a warning signal, not proof of truth.
6. **Real deliverable:** the release target is a tested, signed, installable APK. A source ZIP is an intermediate engineering artifact, not product delivery.

## Logical architecture

```text
Android app (Kotlin + Jetpack Compose)
        | HTTPS / authenticated API
        v
FastAPI application + identity / authorization
        |
        +-- Request policy and budget gate
        +-- Orchestrator / task planner
        +-- Agent registry
        +-- Provider router
        |      +-- Cloud provider adapters
        |      +-- Local OpenAI-compatible endpoint adapter
        |      +-- Future native/local runtime adapter
        +-- Evaluation, critique and synthesis
        +-- Session and long-term memory
        +-- Audit / usage ledger
        |
        +-- PostgreSQL (+ pgvector when justified)
        +-- Redis for bounded queues, concurrency and rate controls
```

## Agent roles for the first usable release

- Planner: decompose the request and define acceptance criteria.
- Analyst: produce the first substantive solution.
- Researcher: retrieve evidence when tools are available; distinguish sourced facts from assumptions.
- Critic: challenge logic, omissions, and unsupported statements.
- Verifier: check claims against evidence or executable tests; never claim checks it did not perform.
- Synthesizer: produce the user-facing result and disclose unresolved uncertainty.

Agent count is not a quality metric. The orchestrator should invoke only roles that add value to the task and should enforce a maximum call count, timeout, concurrency, and token budget.

## Execution modes

- `local_only`: route only to configured local providers; fail clearly if unavailable.
- `cloud_with_approval`: cloud calls are blocked unless a valid approval token/decision exists for that operation and estimated spend is within both per-operation and monthly limits.
- `auto`: prefer an eligible local provider; use cloud only after explicit approval. Never silently fall back to paid cloud.

## Delivery sequence

1. Harden and test the current backend; establish provider interfaces and safe defaults.
2. Implement budget ledger and explicit approval flow before enabling paid providers.
3. Add local endpoint adapter and cloud provider adapters behind the same interface.
4. Add authenticated Android-to-backend communication and a clear approval/cost display.
5. Add durable sessions and memory, then evaluation datasets and regression tests.
6. Build, sign, install and test the APK on the target Android device.

## Explicit non-goals for the first milestone

- No autonomous purchases, subscriptions, or API-key creation.
- No unapproved paid API calls.
- No claim of self-training or unrestricted autonomous learning.
- No assumption that an Android phone can host a frontier-scale model locally.
