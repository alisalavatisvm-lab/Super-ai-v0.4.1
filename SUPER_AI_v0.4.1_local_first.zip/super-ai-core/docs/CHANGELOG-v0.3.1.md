# SUPER AI Core v0.3.1 — Zero-cloud safety patch

## Owner-approved operating mode
- Monthly API budget: USD 0.00.
- Cloud inference: disabled by default and requires explicit `CLOUD_INFERENCE_ENABLED=true`.
- Provider credentials alone do not activate cloud inference.
- The Android client does not contain provider credentials.

## Changes
- Added fail-closed `cloud_inference_enabled` configuration (default `false`).
- Provider activation now requires explicit cloud enablement plus endpoint, key, and model.
- Updated `.env.example`, README, API version, and Android display/version metadata to 0.3.x.
- Added provider safety tests.

## Verification
- `python -m pytest -q`: 10 passed.

## Important limitation
This is a hard off-switch for cloud calls, not yet the full cost-control system. A production paid mode still requires authenticated owner approvals, per-operation cost estimation, transactional budget reservation, and usage reconciliation. Keep cloud inference disabled until those controls are implemented and tested. The Android APK has not been built or device-tested in this environment.
