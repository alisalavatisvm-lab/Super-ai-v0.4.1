# SUPER AI v0.4.1 — Local-first continuity and Android readiness

- Added an Ollama/OpenAI-compatible local inference adapter. It is selected before the cloud adapter whenever configured.
- Kept cloud inference fail-closed; the approved API budget remains zero and credentials alone do not enable cloud calls.
- Injected up to the previous 12 messages of a session into model-backed orchestration requests.
- Added optional bearer-token protection for data endpoints; `/health` remains public.
- Added an optional bearer-token field and saved-session listing/retrieval to the Android client.
- Added a GitHub Actions workflow to build and publish a debug APK artifact after the project is pushed to a GitHub repository.
- Added regression tests for local-provider selection, token enforcement, and conversation-context continuity.

## Verification boundary

Backend automated tests are run in the development environment. Android compilation and device installation are not claimed unless the GitHub workflow or a local Android SDK build completes successfully. Local inference requires the user/operator to install and run a compatible local model on a host reachable by the backend. The shared bearer token is a basic access gate, not full multi-user authentication. SQLite is not encrypted at rest.
