# SUPER AI Core v0.4.0

## Added
- Local SQLite persistence for sessions and chat messages.
- Session creation/listing and message-history API endpoints.
- `/api/v1/chat` now creates or continues a session and stores both user and assistant turns.
- Message metadata records execution mode/provider without storing credentials.
- Database file path is configurable with `DATABASE_PATH` (default: `data/super_ai.db`).

## Safety and limitations
- Cloud inference remains fail-closed and disabled by default. No API spend is enabled by this release.
- SQLite is local persistence, not encrypted storage. Do not expose this development API to untrusted networks or store highly sensitive content.
- The current no-model response remains explicitly labeled DEMO; SQLite memory does not make the assistant a connected language model.
- Android client now carries a session ID between requests and offers a new-conversation control. It remains a development shell; this package does not claim a verified APK build or device installation.
