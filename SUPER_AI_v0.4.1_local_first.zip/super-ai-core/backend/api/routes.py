from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel, Field
from backend.core.agent_registry import list_agents
from backend.core.orchestrator import Orchestrator
from backend.providers.openai_compatible import ProviderNotConfigured
from backend.core.memory_store import MemoryStore
from backend.core.config import settings

router = APIRouter()

def require_access(authorization: str | None) -> None:
    """Optional bearer-token gate; when configured, protects every data endpoint."""
    if settings.api_access_token:
        expected = f"Bearer {settings.api_access_token}"
        if authorization != expected:
            raise HTTPException(status_code=401, detail="Missing or invalid access token")

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=20000)
    session_id: str | None = None

class SessionRequest(BaseModel):
    title: str = Field(default="گفتگوی جدید", min_length=1, max_length=120)

@router.get("/health", tags=["system"])
async def health():
    return {"status": "ok"}

@router.get("/agents", tags=["agents"])
async def agents(authorization: str | None = Header(default=None)):
    require_access(authorization)
    return [agent.__dict__ for agent in list_agents()]

@router.post("/sessions", tags=["memory"])
async def create_session(request: SessionRequest, authorization: str | None = Header(default=None)):
    require_access(authorization)
    return MemoryStore().create_session(request.title)

@router.get("/sessions", tags=["memory"])
async def list_sessions(limit: int = 50, authorization: str | None = Header(default=None)):
    require_access(authorization)
    return MemoryStore().list_sessions(limit)

@router.get("/sessions/{session_id}/messages", tags=["memory"])
async def get_session_messages(session_id: str, limit: int = 200, authorization: str | None = Header(default=None)):
    require_access(authorization)
    messages = MemoryStore().get_messages(session_id, limit)
    if messages is None:
        raise HTTPException(status_code=404, detail="Session not found")
    return messages

@router.post("/chat", tags=["orchestration"])
async def chat(request: ChatRequest, authorization: str | None = Header(default=None)):
    require_access(authorization)
    store = MemoryStore()
    session_id = request.session_id
    if session_id is None:
        session_id = store.create_session(request.message[:80]).get("session_id")
    elif store.get_session(session_id) is None:
        raise HTTPException(status_code=404, detail="Session not found")
    try:
        previous = store.get_messages(session_id, limit=12) or []
        context = "\n".join(f"{m['role'].upper()}: {m['content']}" for m in previous[-12:])
        store.add_message(session_id, "user", request.message)
        result = await Orchestrator().run(request.message, conversation_context=context)
        store.add_message(session_id, "assistant", result["answer"],
                          {"mode": result.get("mode"), "provider": result.get("provider")})
        result["session_id"] = session_id
        return result
    except ProviderNotConfigured as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Orchestration failed: {type(exc).__name__}") from exc
