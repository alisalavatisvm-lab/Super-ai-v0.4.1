from fastapi import FastAPI
from backend.core.config import settings
from backend.api.routes import router

app = FastAPI(title=settings.app_name, version="0.4.0", description="Provider-neutral multi-agent orchestration core")
app.include_router(router, prefix=settings.api_prefix)

@app.get("/", tags=["system"])
async def root():
    return {"service": settings.app_name, "status": "ready", "version": "0.4.0"}
