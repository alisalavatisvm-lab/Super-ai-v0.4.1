from dataclasses import dataclass

@dataclass(frozen=True)
class QualityReport:
    score: float
    completeness: float
    specificity: float
    uncertainty_handling: float
    passed: bool
    notes: tuple[str, ...]

def evaluate_answer(question: str, answer: str, threshold: float) -> QualityReport:
    q_words = {w.lower().strip(".,!?;:") for w in question.split() if len(w) > 3}
    a_words = {w.lower().strip(".,!?;:") for w in answer.split()}
    overlap = len(q_words & a_words) / max(1, len(q_words))
    completeness = min(1.0, len(answer.split()) / 100.0)
    specificity = min(1.0, (len(a_words) / 80.0) + overlap * 0.35)
    uncertainty = 1.0 if any(x in answer.lower() for x in ("uncertain", "assumption", "cannot verify", "not enough information")) else 0.65
    score = round(0.30 * completeness + 0.40 * specificity + 0.30 * uncertainty, 3)
    notes = []
    if len(answer.split()) < 35: notes.append("Answer is short; check whether key aspects are missing.")
    if uncertainty < 1.0: notes.append("Explicitly state assumptions or uncertainty where relevant.")
    return QualityReport(score, round(completeness, 3), round(specificity, 3), uncertainty, score >= threshold, tuple(notes))
