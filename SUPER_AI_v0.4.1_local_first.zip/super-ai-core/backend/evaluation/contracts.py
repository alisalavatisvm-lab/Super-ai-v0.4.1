from dataclasses import dataclass

@dataclass(frozen=True)
class Evaluation:
    factuality: float
    relevance: float
    completeness: float
    safety: float

    def __post_init__(self):
        for name, value in self.__dict__.items():
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must be between 0 and 1")
