from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    app_name: str = "SUPER AI Core"
    api_prefix: str = "/api/v1"
    log_level: str = "INFO"
    model_base_url: str = ""
    model_api_key: str = ""
    model_name: str = ""
    local_model_base_url: str = ""
    local_model_name: str = ""
    local_model_api_key: str = ""
    api_access_token: str = ""
    # Fail-closed: cloud inference remains disabled until the owner explicitly opts in.
    cloud_inference_enabled: bool = False
    model_timeout_seconds: float = 45.0
    max_parallel_agents: int = 4
    quality_threshold: float = 0.72
    max_quality_rounds: int = 2
    database_path: str = "data/super_ai.db"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
