from dataclasses import dataclass

@dataclass(frozen=True)
class AgentDescriptor:
    agent_id: str
    display_name: str
    responsibility: str

DEFAULT_AGENTS = (
    AgentDescriptor("planner", "Planner", "Decompose the request and identify dependencies."),
    AgentDescriptor("analyst", "Analyst", "Develop a substantive solution and state assumptions."),
    AgentDescriptor("critic", "Critic", "Find errors, gaps, risks, and unsupported claims."),
    AgentDescriptor("synthesizer", "Synthesizer", "Produce a coherent answer using the available evidence."),
)

def list_agents() -> list[AgentDescriptor]:
    return list(DEFAULT_AGENTS)
