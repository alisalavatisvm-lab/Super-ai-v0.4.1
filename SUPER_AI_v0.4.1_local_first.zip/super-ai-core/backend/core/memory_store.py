from __future__ import annotations

import json
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from backend.core.config import settings


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class MemoryStore:
    """Small, local-first SQLite store for sessions and chat turns."""

    def __init__(self, db_path: str | None = None) -> None:
        self.db_path = Path(db_path or settings.database_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def initialize(self) -> None:
        with self._connect() as conn:
            conn.execute("PRAGMA journal_mode = WAL")
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS sessions (
                    session_id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS messages (
                    message_id TEXT PRIMARY KEY,
                    session_id TEXT NOT NULL REFERENCES sessions(session_id) ON DELETE CASCADE,
                    role TEXT NOT NULL CHECK(role IN ('user', 'assistant', 'system')),
                    content TEXT NOT NULL,
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_messages_session_created
                    ON messages(session_id, created_at);
            """)

    def create_session(self, title: str = "گفتگوی جدید") -> dict[str, Any]:
        session_id, now = str(uuid.uuid4()), _now()
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO sessions(session_id,title,created_at,updated_at) VALUES(?,?,?,?)",
                (session_id, title[:120], now, now),
            )
        return self.get_session(session_id)

    def get_session(self, session_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM sessions WHERE session_id=?", (session_id,)).fetchone()
        return dict(row) if row else None

    def list_sessions(self, limit: int = 50) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT s.*, (SELECT COUNT(*) FROM messages m WHERE m.session_id=s.session_id) AS message_count "
                "FROM sessions s ORDER BY updated_at DESC LIMIT ?", (max(1, min(limit, 100)),)
            ).fetchall()
        return [dict(row) for row in rows]

    def add_message(self, session_id: str, role: str, content: str,
                    metadata: dict[str, Any] | None = None) -> dict[str, Any]:
        if role not in {"user", "assistant", "system"}:
            raise ValueError("unsupported message role")
        if not content.strip():
            raise ValueError("message content must not be empty")
        message_id, now = str(uuid.uuid4()), _now()
        with self._connect() as conn:
            exists = conn.execute("SELECT 1 FROM sessions WHERE session_id=?", (session_id,)).fetchone()
            if not exists:
                raise KeyError("session not found")
            conn.execute(
                "INSERT INTO messages(message_id,session_id,role,content,metadata_json,created_at) VALUES(?,?,?,?,?,?)",
                (message_id, session_id, role, content, json.dumps(metadata or {}, ensure_ascii=False), now),
            )
            conn.execute("UPDATE sessions SET updated_at=? WHERE session_id=?", (now, session_id))
        return {"message_id": message_id, "session_id": session_id, "role": role,
                "content": content, "metadata": metadata or {}, "created_at": now}

    def get_messages(self, session_id: str, limit: int = 200) -> list[dict[str, Any]] | None:
        with self._connect() as conn:
            exists = conn.execute("SELECT 1 FROM sessions WHERE session_id=?", (session_id,)).fetchone()
            if not exists:
                return None
            rows = conn.execute(
                "SELECT * FROM (SELECT * FROM messages WHERE session_id=? ORDER BY created_at DESC LIMIT ?) "
                "ORDER BY created_at ASC", (session_id, max(1, min(limit, 500)))
            ).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["metadata"] = json.loads(item.pop("metadata_json"))
            result.append(item)
        return result
