from __future__ import annotations
import asyncio
from dataclasses import dataclass
from typing import Callable
from backend.core.config import settings
from backend.providers.openai_compatible import OpenAICompatibleProvider
from backend.providers.local_ollama import LocalOllamaProvider
from backend.evaluation.quality import evaluate_answer

@dataclass
class AgentResult:
    agent_id: str
    output: str

class OrchestrationError(RuntimeError):
    pass

class Orchestrator:
    def __init__(self, provider: OpenAICompatibleProvider | None = None) -> None:
        if provider is not None:
            self.provider = provider
        else:
            local = LocalOllamaProvider()
            self.provider = local if local.configured else OpenAICompatibleProvider()
        self.max_concurrency = max(1, settings.max_parallel_agents)

    async def _call(self, role: str, instruction: str, task: str) -> str:
        return await self.provider.generate(system_prompt=f"You are the {role} agent in SUPER AI. {instruction} Be precise. Distinguish facts, assumptions, and uncertainty. Do not invent sources.", user_prompt=task)

    async def run(self, task: str, conversation_context: str = "") -> dict:
        if not task.strip():
            raise ValueError("task must not be empty")
        if not self.provider.configured:
            return self._demo_result(task)

        if conversation_context:
            task = f"CONVERSATION HISTORY (oldest first):\n{conversation_context}\n\nCURRENT USER REQUEST:\n{task}"

        semaphore = asyncio.Semaphore(self.max_concurrency)
        async def bounded(role: str, instruction: str, prompt: str) -> str:
            async with semaphore:
                return await self._call(role, instruction, prompt)

        plan, analysis = await asyncio.gather(
            bounded("Planner", "Create a concise plan and list critical subquestions.", task),
            bounded("Analyst", "Solve the user's request directly and thoroughly.", task),
        )
        critique = await bounded("Critic", "Review the draft for factual gaps, logic errors, risks and missing caveats. Give actionable corrections.", f"USER REQUEST:\n{task}\n\nPLAN:\n{plan}\n\nDRAFT:\n{analysis}")
        synthesis_prompt = f"USER REQUEST:\n{task}\n\nPLAN:\n{plan}\n\nANALYSIS:\n{analysis}\n\nCRITIQUE:\n{critique}\n\nWrite the best final answer. Resolve valid criticisms. Do not claim verification that was not performed."
        answer = await bounded("Synthesizer", "Synthesize a clear, complete final response.", synthesis_prompt)
        report = evaluate_answer(task, answer, settings.quality_threshold)
        rounds = 0
        while not report.passed and rounds < settings.max_quality_rounds:
            rounds += 1
            answer = await bounded("Revision", "Improve the answer against the quality feedback. Preserve correctness over brevity.", f"REQUEST:\n{task}\n\nCURRENT ANSWER:\n{answer}\n\nQUALITY FEEDBACK:\n{report.notes}")
            report = evaluate_answer(task, answer, settings.quality_threshold)
        return {"answer": answer, "mode": "multi_agent", "provider": self.provider.provider_name,
                "quality": report.__dict__, "rounds": rounds,
                "agent_outputs": {"plan": plan, "analysis": analysis, "critique": critique}}

    def _demo_result(self, task: str) -> dict:
        answer = ("SUPER AI is running in DEMO mode. The backend and orchestration endpoint are active, "
                  "but no language model is connected yet. Configure MODEL_BASE_URL, MODEL_API_KEY, "
                  "and MODEL_NAME in the environment to enable real multi-agent model execution.\n\n"
                  f"Your request was received: {task}\n\n"
                  "No model-generated analysis has been performed in this mode.")
        report = evaluate_answer(task, answer, settings.quality_threshold)
        return {"answer": answer, "mode": "demo", "provider": None, "quality": report.__dict__,
                "rounds": 0, "agent_outputs": {}}

async def run_parallel(task: str, agents, *, max_concurrency: int = 4):
    if not task.strip(): raise ValueError("task must not be empty")
    if max_concurrency < 1: raise ValueError("max_concurrency must be at least 1")
    semaphore = asyncio.Semaphore(max_concurrency)
    async def invoke(agent):
        async with semaphore:
            return AgentResult(agent_id=agent.agent_id, output=await agent.run(task))
    return await asyncio.gather(*(invoke(agent) for agent in agents))
