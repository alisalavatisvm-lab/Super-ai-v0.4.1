from __future__ import annotations
import httpx
from backend.core.config import settings

class ProviderNotConfigured(RuntimeError):
    pass

class OpenAICompatibleProvider:
    """Adapter for providers exposing the OpenAI Chat Completions API shape."""
    provider_name = "openai-compatible"

    def __init__(self) -> None:
        self.base_url = settings.model_base_url.rstrip("/")
        self.api_key = settings.model_api_key
        self.model = settings.model_name
        self.timeout = settings.model_timeout_seconds

    @property
    def configured(self) -> bool:
        # Credentials alone must never activate a potentially billable provider.
        return bool(settings.cloud_inference_enabled and self.base_url and self.api_key and self.model)

    async def generate(self, *, system_prompt: str, user_prompt: str) -> str:
        if not self.configured:
            raise ProviderNotConfigured("Cloud inference is disabled by default. Explicitly enable CLOUD_INFERENCE_ENABLED and configure provider credentials only after approving a spending limit.")
        url = f"{self.base_url}/chat/completions"
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        payload = {"model": self.model, "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ], "temperature": 0.2}
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(url, headers=headers, json=payload)
            response.raise_for_status()
            data = response.json()
        try:
            content = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise RuntimeError("Provider returned an unexpected response shape") from exc
        if not isinstance(content, str) or not content.strip():
            raise RuntimeError("Provider returned empty content")
        return content.strip()
