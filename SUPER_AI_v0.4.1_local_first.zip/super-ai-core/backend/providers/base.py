from typing import Protocol

class ModelProvider(Protocol):
    provider_name: str

    async def generate(self, *, system_prompt: str, user_prompt: str) -> str:
        """Return generated text. Implementations must handle provider errors explicitly."""
        ...
