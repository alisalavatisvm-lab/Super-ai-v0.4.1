from __future__ import annotations
import httpx
from backend.core.config import settings

class LocalModelNotConfigured(RuntimeError):
    pass

class LocalOllamaProvider:
    """OpenAI-compatible adapter for a self-hosted local model (e.g. Ollama)."""
    provider_name = "local-openai-compatible"

    def __init__(self) -> None:
        self.base_url = settings.local_model_base_url.rstrip("/")
        self.model = settings.local_model_name
        self.timeout = settings.model_timeout_seconds

    @property
    def configured(self) -> bool:
        return bool(self.base_url and self.model)

    async def generate(self, *, system_prompt: str, user_prompt: str) -> str:
        if not self.configured:
            raise LocalModelNotConfigured("Local model is not configured")
        headers = {"Content-Type": "application/json"}
        if settings.local_model_api_key:
            headers["Authorization"] = f"Bearer {settings.local_model_api_key}"
        payload = {"model": self.model, "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ], "temperature": 0.2}
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(f"{self.base_url}/chat/completions", headers=headers, json=payload)
            response.raise_for_status()
            data = response.json()
        try:
            content = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise RuntimeError("Local model returned an unexpected response shape") from exc
        if not isinstance(content, str) or not content.strip():
            raise RuntimeError("Local model returned empty content")
        return content.strip()
